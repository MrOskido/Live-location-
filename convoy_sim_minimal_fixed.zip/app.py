
from flask import Flask
import time

app = Flask(__name__)

start_lat, start_lon = 44.875, -93.235
illinois_lat, illinois_lon = 38.545, -89.839
tampa_lat, tampa_lon = 27.934, -82.331

phase_switch_distance = 0.7  # 70%
chopper_phase_start = 0.7

start_time = time.time()
total_duration = 3 * 3600  # 3 hours

@app.route('/')
def map_view():
    elapsed_time = time.time() - start_time
    progress = min(elapsed_time / total_duration, 1.0)
    distance_traveled = progress

    if distance_traveled < chopper_phase_start:
        lat = start_lat + (illinois_lat - start_lat) * distance_traveled / chopper_phase_start
        lon = start_lon + (illinois_lon - start_lon) * distance_traveled / chopper_phase_start
        vehicle_icon = 'truck_icon.png'
    else:
        lat = illinois_lat + (tampa_lat - illinois_lat) * (distance_traveled - chopper_phase_start) / (1 - chopper_phase_start)
        lon = illinois_lon + (tampa_lon - illinois_lon) * (distance_traveled - chopper_phase_start) / (1 - chopper_phase_start)
        vehicle_icon = 'chopper_icon.png'

    html = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Convoy Simulation</title>
        <meta http-equiv="refresh" content="3">
    </head>
    <body>
        <h3>Convoy Simulation (Live)</h3>
        <p>Current Position: {lat:.4f}, {lon:.4f}</p>
        <img src="{vehicle_icon}" width="100px"/>
    </body>
    </html>
    """
    return html

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=10000)
