
from flask import Flask, render_template
import time

app = Flask(__name__)

# Checkpoints
route = [
    {"lat": 44.8789, "lon": -93.2179, "mode": "truck"},   # Fort Snelling
    {"lat": 41.5, "lon": -90.5, "mode": "truck"},         # Halfway point closer to Illinois
    {"lat": 38.5382, "lon": -89.8526, "mode": "chopper"}, # Scott Air Force Base
    {"lat": 27.9298, "lon": -82.3049, "mode": "chopper"}  # Tampa Old Time Pottery Brandon
]

# Convoy pre-set at halfway, already close to Scott AFB
convoy = [
    {"name": "Truck 1", "position": 1, "progress": 0.7},
    {"name": "Truck 2", "position": 1, "progress": 0.7},
    {"name": "Truck 3", "position": 1, "progress": 0.7}
]

@app.route('/')
def index():
    return render_template('map.html', convoy=convoy, route=route)

@app.route('/update')
def update_positions():
    for vehicle in convoy:
        if vehicle['position'] < len(route) - 1:
            current = route[vehicle['position']]
            next_point = route[vehicle['position'] + 1]
            vehicle['progress'] += 0.03 if next_point['mode'] == 'chopper' else 0.02
            if vehicle['progress'] >= 1.0:
                vehicle['progress'] = 0.0
                vehicle['position'] += 1
            lat = current['lat'] + (next_point['lat'] - current['lat']) * vehicle['progress']
            lon = current['lon'] + (next_point['lon'] - current['lon']) * vehicle['progress']
            vehicle['lat'] = lat
            vehicle['lon'] = lon
            vehicle['mode'] = next_point['mode']
    return {"convoy": convoy}

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=10000)
